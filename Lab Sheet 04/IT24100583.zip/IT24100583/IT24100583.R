setwd("C:\\Users\\it24100583\\Desktop\\IT24100583")

#01
branch_data<-read.table("Exercise.txt",header=TRUE,
                        sep = ",")
fix(branch_data)

attach(branch_data)

#02
str(branch_data)

#03
boxplot(branch_data$Sales_X1, main="Boxplot - sales",
        ylab="Sales")

#04
summary(branch_data$Advertising_X2)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#05
find_outliers<- function(v) {
  Q1 <- quantile(v, 0.25)
  Q3 <- quantile(v,0.75)
  IQR <- Q3 - Q1
  lower <- Q1 - 1.5*IQR
  upper <- Q3 + 1.5*IQR
  v[v < lower | v > upper]
}
find_outliers(branch_data$Years_X3)
